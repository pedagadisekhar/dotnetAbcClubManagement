﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApplication4.Models;

namespace WebApplication4.Services
{
    public interface IClassService
    {
        List<ClassModel> GetAllClasses();
        ClassModel GetClassById(int id);
        string AddClass(ClassModel newClass);
        string DeleteClass(int id);
    }
}