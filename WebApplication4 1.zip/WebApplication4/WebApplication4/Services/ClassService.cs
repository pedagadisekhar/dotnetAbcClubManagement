﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApplication4.Models;
using WebApplication4.Repositories;

namespace WebApplication4.Services
{
    public class ClassService : IClassService
    {
        private readonly IClassRepository _classRepository;

        public ClassService(IClassRepository classRepository)
        {
            _classRepository = classRepository;
        }

        public List<ClassModel> GetAllClasses()
        {
            return _classRepository.GetAllClasses();
        }

        public ClassModel GetClassById(int id)
        {
            return _classRepository.GetClassById(id);
        }

        public string AddClass(ClassModel newClass)
        {
            if (newClass.EndDate <= DateTime.Now)
            {
                return "End date must be in the future.";
            }

            if (_classRepository.GetAllClasses().Exists(c => c.StartDate == newClass.StartDate))
            {
                return "A class is already scheduled for this date.";
            }

            _classRepository.AddClass(newClass);
            return "Class created successfully.";
        }

        public string DeleteClass(int id)
        {
            var classItem = _classRepository.GetClassById(id);
            if (classItem == null)
            {
                return "Class not found.";
            }

            _classRepository.DeleteClass(id);
            return "Class deleted successfully.";
        }
    }
}