﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApplication4.Models;
using WebApplication4.Repositories;

namespace WebApplication4.Services
{
    public class BookingService : IBookingService
    {
        private readonly IBookingRepository _bookingRepository;

        public BookingService()
        {
            _bookingRepository = new BookingRepository();
        }

        public List<BookingModel> GetAllBookings()
        {
            return _bookingRepository.GetAllBookings();
        }

        public BookingModel GetBookingById(int id)
        {
            return _bookingRepository.GetBookingById(id);
        }

        public bool CreateBooking(BookingModel newBooking)
        {
            return _bookingRepository.AddBooking(newBooking);
        }

        public List<BookingModel> SearchBookings(string memberName, DateTime? startDate, DateTime? endDate)
        {
            return _bookingRepository.SearchBookings(memberName, startDate, endDate);
        }
    }
}