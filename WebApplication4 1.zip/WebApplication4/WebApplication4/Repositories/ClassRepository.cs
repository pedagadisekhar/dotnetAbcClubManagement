﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApplication4.Models;

namespace WebApplication4.Repositories
{
    public class ClassRepository : IClassRepository
    {
        private static List<ClassModel> _classes = new List<ClassModel>
        {
            new ClassModel { Id = 1, Name = "Yoga", StartDate = DateTime.Parse("2025-02-01"), EndDate = DateTime.Parse("2025-02-10"), StartTime = TimeSpan.FromHours(10), Capacity = 15, Duration = 60 },
            new ClassModel { Id = 2, Name = "gym", StartDate = DateTime.Parse("2025-02-05"), EndDate = DateTime.Parse("2025-02-20"), StartTime = TimeSpan.FromHours(14), Capacity = 10, Duration = 45 }
        };

        public List<ClassModel> GetAllClasses()
        {
            return _classes;
        }

        public ClassModel GetClassById(int id)
        {
            return _classes.FirstOrDefault(c => c.Id == id);
        }

        public void AddClass(ClassModel newClass)
        {
            newClass.Id = _classes.Count + 1;
            _classes.Add(newClass);
        }

        public void DeleteClass(int id)
        {
            var classItem = _classes.FirstOrDefault(c => c.Id == id);
            if (classItem != null)
            {
                _classes.Remove(classItem);
            }
        }
    }
}