﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApplication4.Models;

namespace WebApplication4.Repositories
{
    public class BookingRepository : IBookingRepository
    {
        private static List<BookingModel> _bookings = new List<BookingModel>
        {
            new BookingModel { Id = 1, MemberName = "John Doe", ClassId = 1, ParticipationDate = new DateTime(2025, 5, 10) },
            new BookingModel { Id = 2, MemberName = "Alice Smith", ClassId = 2, ParticipationDate = new DateTime(2025, 5, 12) },
            new BookingModel { Id = 3, MemberName = "Bob Johnson", ClassId = 3, ParticipationDate = new DateTime(2025, 5, 15) },
            new BookingModel { Id = 4, MemberName = "Emma Brown", ClassId = 1, ParticipationDate = new DateTime(2025, 5, 18) },
            new BookingModel { Id = 5, MemberName = "John Doe", ClassId = 2, ParticipationDate = new DateTime(2025, 5, 20) }
        };

        public List<BookingModel> GetAllBookings()
        {
            return _bookings;
        }

        public BookingModel GetBookingById(int id)
        {
            return _bookings.FirstOrDefault(b => b.Id == id);
        }


       

        public bool AddBooking(BookingModel newBooking)
        {
            
            var classRepo = new ClassRepository();
            var classDetails = classRepo.GetClassById(newBooking.ClassId);

            if (classDetails == null) { 
                return false;
            }
            
            int currentBookings = _bookings.Count(b => b.ClassId == newBooking.ClassId && b.ParticipationDate == newBooking.ParticipationDate);

            if (currentBookings >= classDetails.Capacity)
                return false; 

           
            if (newBooking.ParticipationDate <= DateTime.Today)
                return false; 

            newBooking.Id = _bookings.Count + 1; 
            _bookings.Add(newBooking);
            return true;
        }


        // 


        public List<BookingModel> SearchBookings(string memberName, DateTime? startDate, DateTime? endDate)
        {
            var query = _bookings.AsQueryable();

            if (!string.IsNullOrEmpty(memberName))
            {
                query = query.Where(b => b.MemberName.Equals(memberName, StringComparison.OrdinalIgnoreCase));
            }

            if (startDate.HasValue)
            {
                query = query.Where(b => b.ParticipationDate >= startDate.Value);
            }

            if (endDate.HasValue)
            {
                query = query.Where(b => b.ParticipationDate <= endDate.Value);
            }

            return query.ToList();
        }

    }
}