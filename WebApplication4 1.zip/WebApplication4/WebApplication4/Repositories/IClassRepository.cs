﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApplication4.Models;

namespace WebApplication4.Repositories
{
    public interface IClassRepository
    {
        List<ClassModel> GetAllClasses();  
        ClassModel GetClassById(int id);  
        void AddClass(ClassModel newClass);
        void DeleteClass(int id);
    }
}

