﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApplication4.Models;


namespace WebApplication4.Repositories
{
    public interface IBookingRepository
    {
        List<BookingModel> GetAllBookings();
        BookingModel GetBookingById(int id);
        bool AddBooking(BookingModel newBooking);
        List<BookingModel> SearchBookings(string memberName, DateTime? startDate, DateTime? endDate);
    }
}