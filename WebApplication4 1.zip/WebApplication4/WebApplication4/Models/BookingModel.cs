﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication4.Models
{
    public class BookingModel
    {
        public int Id { get; set; }  
        public string MemberName { get; set; } 
        public int ClassId { get; set; } 
        public DateTime ParticipationDate { get; set; }
    }

    public class BookingSearchRequest
    {
        public string MemberName { get; set; }
        public string StartDate { get; set; } 
        public string EndDate { get; set; }    
    }
}