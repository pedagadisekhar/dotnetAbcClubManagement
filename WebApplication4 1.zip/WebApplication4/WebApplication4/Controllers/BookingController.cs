﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Http;
using WebApplication4.Services;
using WebApplication4.Models;


namespace WebApplication4.Controllers
{
    public class BookingController : ApiController
    {
        private readonly IBookingService _bookingService;

        public BookingController()
        {
            _bookingService = new BookingService();
        }

      
        [System.Web.Http.Route("api/bookings")]
        public IHttpActionResult GetAllBookings()
        {
            var bookings = _bookingService.GetAllBookings();
            return Ok(bookings);
        }


       [System.Web.Http.Route("api/GetBookingById")]
        public IHttpActionResult GetBookingById(int id)
        {
            var booking = _bookingService.GetBookingById(id);
            if (booking == null)
                return NotFound();

            return Ok(booking);
        }

        //API to create a booking

        [System.Web.Http.Route("api/CreateBooking")]
        public IHttpActionResult CreateBooking([FromBody] BookingModel newBooking)
        {
            if (newBooking == null)
                return BadRequest("Invalid booking data.");

            bool isSuccess = _bookingService.CreateBooking(newBooking);

            if (!isSuccess)
                return BadRequest("Class is full or invalid participation date.");

            return Ok("Booking created successfully.");
        }

        // POST: api/bookings
        [System.Web.Http.Route("api/SearchBookings")]

        public IHttpActionResult SearchBookings([FromBody] BookingSearchRequest request)
        {
            if (request == null)
                return BadRequest("Invalid request data.");

            DateTime? start = null, end = null;
            DateTime parsedStart, parsedEnd;

            if (!string.IsNullOrEmpty(request.StartDate) && DateTime.TryParse(request.StartDate, out parsedStart))
            {
                start = parsedStart;
            }

            if (!string.IsNullOrEmpty(request.EndDate) && DateTime.TryParse(request.EndDate, out parsedEnd))
            {
                end = parsedEnd;
            }

            var bookings = _bookingService.SearchBookings(request.MemberName, start, end);
            return Ok(bookings);
        }

    }
}