﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication4.Models;
using WebApplication4.Repositories;
using WebApplication4.Services;
using System.Web.Http;

namespace WebApplication4.Controllers
{
    public class AbcClubManagementController : Controller
    {
        //
        // GET: /AbcClubManagement/
        public ActionResult Index()
        {
            return View();
        }
        public class ClassesController : ApiController
        {
            private readonly IClassService _classService;

            public ClassesController()
            {
                _classService = new ClassService(new ClassRepository());
            }

             [System.Web.Http.HttpGet]
             [System.Web.Http.Route("api/GetAllClasses")]
            public IHttpActionResult GetAllClasses()
            {
                return Ok(_classService.GetAllClasses());
            }

            [System.Web.Http.HttpGet]
            [System.Web.Http.Route("api/GetClass")]
            public IHttpActionResult GetClass(int id)
            {
                var classItem = _classService.GetClassById(id);
                if (classItem == null)
                {
                    return NotFound();
                }
                return Ok(classItem);
            }

            [System.Web.Http.HttpPost]
            [System.Web.Http.Route("api/CreateClass")]
            public IHttpActionResult CreateClass([FromBody] ClassModel newClass)
            {
                var result = _classService.AddClass(newClass);
                if (result != "Class created successfully.")
                {
                    return BadRequest(result);
                }

                return Ok(newClass);
            }

            //[HttpDelete]
            //[Route("{id}")]
            //public IHttpActionResult DeleteClass(int id)
            //{
            //    var result = _classService.DeleteClass(id);
            //    if (result == "Class not found.")
            //    {
            //        return NotFound();
            //    }
            //    return Ok(result);
            //}
        }
	}
}