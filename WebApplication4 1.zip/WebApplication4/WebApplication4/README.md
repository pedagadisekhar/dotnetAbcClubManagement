﻿

##  API 1: Create a Class
### **Endpoint:**  
`POST /api/CreateClass`
### **Request Payload:**
```json
{
  "name": "Pilates",
  "startDate": "2025-05-01",
  "endDate": "2025-05-20",
  "startTime": "14:00",
  "duration": 60,
  "capacity": 10
}


----------------------------------------------

##  API : get all bookings
### **Endpoint:**
`Get /api/GetAllClasses 


---------------------------------------------

##  API : create Booking
### **Endpoint:**
`POST /api/CreateBooking
### **Request Payload:**
```json
{
  "memberName": "chandra",
  "classId": 2,
  "participationDate": "2025-05-10"
}

--------------------------------------

##  API : get all bookings
### **Endpoint:**
GET /api/bookings  

--------------------------------------

##  API : Search a bookings
### **Endpoint:**  
`POST api/SearchBookings`
### **Request Payload:**

{
  "memberName": "John Doe",
  "startDate": "2025-05-01",
  "endDate": "2025-05-20"
}

--------------------------------------